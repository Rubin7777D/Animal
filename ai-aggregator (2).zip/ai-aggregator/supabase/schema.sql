-- Выполнить в Supabase Dashboard → SQL Editor.

-- Таблица профилей: 1 к 1 с auth.users, сюда переносим баланс токенов
-- из lib/tokens.ts (in-memory demo-хранилище) в реальную БД.
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text,
  token_balance integer not null default 300, -- стартовый бонус новому юзеру
  plan text not null default 'trial',
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;

-- Пользователь может читать и обновлять только свою строку.
create policy "Users can view own profile"
  on public.profiles for select
  using (auth.uid() = id);

create policy "Users can update own profile"
  on public.profiles for update
  using (auth.uid() = id);

-- Функция + триггер: как только в auth.users появляется новый
-- пользователь (обычная регистрация ИЛИ вход через Google),
-- автоматически создаём для него запись в profiles.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, username)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'username', split_part(new.email, '@', 1))
  );
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- Списание токенов лучше делать через RPC-функцию (атомарно,
-- без гонки при параллельных запросах), а не UPDATE из route handler'а.
create or replace function public.deduct_tokens(user_id uuid, amount integer)
returns integer
language plpgsql
security definer set search_path = public
as $$
declare
  new_balance integer;
begin
  update public.profiles
  set token_balance = token_balance - amount
  where id = user_id and token_balance >= amount
  returning token_balance into new_balance;

  if new_balance is null then
    raise exception 'insufficient_tokens';
  end if;

  return new_balance;
end;
$$;
