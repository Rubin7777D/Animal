import { createServerClient } from "@supabase/ssr";
import { cookies } from "next/headers";

// Используется в серверных компонентах и route handlers, где нужно
// прочитать/установить сессию пользователя через cookies запроса.
export function createClient() {
  const cookieStore = cookies();

  return createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() {
          return cookieStore.getAll();
        },
        setAll(cookiesToSet) {
          try {
            cookiesToSet.forEach(({ name, value, options }) =>
              cookieStore.set(name, value, options)
            );
          } catch {
            // setAll вызывается из Server Component — это нормально,
            // если у вас уже есть middleware, обновляющий сессию.
          }
        },
      },
    }
  );
}
