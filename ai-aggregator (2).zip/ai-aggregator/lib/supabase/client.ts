import { createBrowserClient } from "@supabase/ssr";

// Используется во всех клиентских компонентах ("use client"),
// где нужно вызвать supabase.auth.signIn / signUp / signOut и т.д.
export function createClient() {
  return createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );
}
