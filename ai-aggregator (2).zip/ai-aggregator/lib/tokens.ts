// Демонстрационное хранилище токенов в памяти процесса.
// В проде замени на реальную БД (Postgres/Supabase/etc) и привязку к user_id из авторизации.

export const PLANS = {
  minimal: { label: "Минимальный", tokens: 300, priceRub: 990 },
  basic: { label: "Базовый", tokens: 600, priceRub: 1790 },
  premium: { label: "Премиум", tokens: 1200, priceRub: 3290 },
} as const;

// Примерная стоимость одной генерации в токенах — подстрой под реальные тарифы Volcengine/Nano Banana.
export const TOKEN_COSTS = {
  image: 4,
  video: 40,
} as const;

type Balances = Record<string, number>;

const balances: Balances = {
  demo: 300,
};

export function getBalance(userId: string) {
  return balances[userId] ?? 0;
}

export function deduct(userId: string, amount: number) {
  const current = getBalance(userId);
  if (current < amount) {
    return { ok: false as const, balance: current };
  }
  balances[userId] = current - amount;
  return { ok: true as const, balance: balances[userId] };
}

export function credit(userId: string, amount: number) {
  balances[userId] = getBalance(userId) + amount;
  return balances[userId];
}
