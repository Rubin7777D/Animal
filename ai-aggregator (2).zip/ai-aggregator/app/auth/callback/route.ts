import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

// И ссылка подтверждения email, и редирект после Google OAuth приходят
// сюда с параметром ?code=... — Supabase выдаёт его в обоих случаях
// (PKCE-флоу). Мы обмениваем code на настоящую сессию (cookie),
// и пользователь сразу становится авторизован.
export async function GET(request: Request) {
  const { searchParams, origin } = new URL(request.url);
  const code = searchParams.get("code");
  const redirectTo = searchParams.get("redirectTo") || "/";

  if (code) {
    const supabase = createClient();
    const { error } = await supabase.auth.exchangeCodeForSession(code);

    if (!error) {
      // Успех: email подтверждён / Google-вход выполнен — сессия активна.
      return NextResponse.redirect(`${origin}${redirectTo}`);
    }
  }

  // Код отсутствует или невалиден/просрочен.
  return NextResponse.redirect(`${origin}/auth/auth-code-error`);
}
