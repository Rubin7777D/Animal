import { Suspense } from "react";
import AuthTabs from "@/components/auth/AuthTabs";

export default function AuthPage() {
  return (
    <div className="flex min-h-dvh items-center justify-center bg-base-950 px-4">
      {/* Suspense нужен, т.к. LoginForm читает useSearchParams() (?redirectTo=...) */}
      <Suspense fallback={null}>
        <AuthTabs />
      </Suspense>
    </div>
  );
}
