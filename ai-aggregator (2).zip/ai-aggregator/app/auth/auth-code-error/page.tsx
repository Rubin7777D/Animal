import Link from "next/link";

export default function AuthCodeError() {
  return (
    <div className="flex min-h-dvh flex-col items-center justify-center gap-4 bg-base-950 px-4 text-center">
      <h1 className="font-display text-xl font-semibold text-white">
        Ссылка недействительна
      </h1>
      <p className="max-w-sm text-sm text-mist-400">
        Ссылка для подтверждения устарела или уже была использована.
        Попробуйте зарегистрироваться заново или войти, если аккаунт уже
        подтверждён.
      </p>
      <Link
        href="/auth"
        className="rounded-xl2 bg-ember-500 px-4 py-2.5 text-sm font-medium text-base-950 hover:bg-ember-400"
      >
        Вернуться на страницу входа
      </Link>
    </div>
  );
}
