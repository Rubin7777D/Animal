import { NextRequest, NextResponse } from "next/server";
import { deduct, TOKEN_COSTS } from "@/lib/tokens";

// Nano Banana — это разговорное название модели генерации изображений Gemini
// (доступна через Google AI Studio / Gemini API как gemini-2.5-flash-image).
// Замени NANO_BANANA_API_KEY и URL на актуальные для выбранного тобой провайдера/реселлера.

export async function POST(req: NextRequest) {
  const { prompt, userId = "demo" } = await req.json();

  if (!prompt || typeof prompt !== "string") {
    return NextResponse.json({ error: "Поле prompt обязательно" }, { status: 400 });
  }

  const charge = deduct(userId, TOKEN_COSTS.image);
  if (!charge.ok) {
    return NextResponse.json(
      { error: "Недостаточно токенов", balance: charge.balance },
      { status: 402 }
    );
  }

  try {
    const apiKey = process.env.NANO_BANANA_API_KEY;
    if (!apiKey) {
      // Без ключа возвращаем мок-ответ, чтобы фронтенд можно было тестировать без бэкенд-ключей.
      return NextResponse.json({
        mock: true,
        imageUrl: "https://placehold.co/768x768/1C1E26/F59E33?text=Nano+Banana+mock",
        balance: charge.balance,
      });
    }

    const upstream = await fetch(
      "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-image:generateContent",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-goog-api-key": apiKey,
        },
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }] }],
        }),
      }
    );

    if (!upstream.ok) {
      const detail = await upstream.text();
      return NextResponse.json({ error: "Ошибка провайдера", detail }, { status: 502 });
    }

    const data = await upstream.json();

    // Gemini возвращает картинку как base64 внутри inlineData — достаём её
    // и собираем data URL, который можно сразу вставить в <img src="...">.
    const inlineData = data?.candidates?.[0]?.content?.parts?.find(
      (p: any) => p.inlineData
    )?.inlineData;

    if (!inlineData) {
      return NextResponse.json(
        { error: "Модель не вернула изображение", detail: data },
        { status: 502 }
      );
    }

    const imageUrl = `data:${inlineData.mimeType};base64,${inlineData.data}`;
    return NextResponse.json({ imageUrl, balance: charge.balance });
  } catch (err) {
    return NextResponse.json({ error: "Внутренняя ошибка", detail: String(err) }, { status: 500 });
  }
}
