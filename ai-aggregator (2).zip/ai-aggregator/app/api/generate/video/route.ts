import { NextRequest, NextResponse } from "next/server";
import { deduct, TOKEN_COSTS } from "@/lib/tokens";

// Прямой доступ к Volcengine (Seedance) идёт через Ark API.
// Нужны VOLCENGINE_API_KEY (или AK/SK для подписи запроса) — смотри документацию
// Volcengine Ark: создание задачи генерации видео + опрос статуса по task_id.

export async function POST(req: NextRequest) {
  const { prompt, userId = "demo", durationSeconds = 5 } = await req.json();

  if (!prompt || typeof prompt !== "string") {
    return NextResponse.json({ error: "Поле prompt обязательно" }, { status: 400 });
  }

  const cost = TOKEN_COSTS.video * Math.max(1, Math.ceil(durationSeconds / 5));
  const charge = deduct(userId, cost);
  if (!charge.ok) {
    return NextResponse.json(
      { error: "Недостаточно токенов", balance: charge.balance },
      { status: 402 }
    );
  }

  const apiKey = process.env.VOLCENGINE_API_KEY;
  if (!apiKey) {
    // Мок-ответ для разработки без реального ключа.
    return NextResponse.json({
      mock: true,
      taskId: "mock-task-id",
      status: "queued",
      balance: charge.balance,
    });
  }

  try {
    // Пример вызова Ark Content Generation API (эндпоинт/модель уточни по своей учётке).
    const upstream = await fetch(
      "https://ark.cn-beijing.volces.com/api/v3/contents/generations/tasks",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model: "seedance-1-0-pro",
          content: [{ type: "text", text: prompt }],
        }),
      }
    );

    if (!upstream.ok) {
      const detail = await upstream.text();
      return NextResponse.json({ error: "Ошибка провайдера", detail }, { status: 502 });
    }

    const data = await upstream.json();
    return NextResponse.json({ data, balance: charge.balance });
  } catch (err) {
    return NextResponse.json({ error: "Внутренняя ошибка", detail: String(err) }, { status: 500 });
  }
}
