import { NextRequest, NextResponse } from "next/server";
import { getBalance } from "@/lib/tokens";

export async function GET(req: NextRequest) {
  const userId = req.nextUrl.searchParams.get("userId") ?? "demo";
  return NextResponse.json({ balance: getBalance(userId) });
}
