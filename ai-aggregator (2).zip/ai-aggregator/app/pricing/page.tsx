import Link from "next/link";
import { PLANS, TOKEN_COSTS } from "@/lib/tokens";

const planOrder: Array<keyof typeof PLANS> = ["minimal", "basic", "premium"];

export default function PricingPage() {
  return (
    <div className="min-h-dvh px-6 py-16">
      <div className="mx-auto max-w-4xl">
        <Link href="/" className="text-sm text-mist-400 hover:text-mist-300">
          ← Назад в чат
        </Link>

        <h1 className="mt-6 font-display text-3xl font-semibold text-white md:text-4xl">
          Тарифы
        </h1>
        <p className="mt-2 max-w-lg text-sm text-mist-400">
          Токены тратятся на генерацию: фото — {TOKEN_COSTS.image} токенов,
          видео — от {TOKEN_COSTS.video} токенов за ролик.
        </p>

        <div className="mt-10 grid gap-4 md:grid-cols-3">
          {planOrder.map((key, i) => {
            const plan = PLANS[key];
            const featured = key === "basic";
            return (
              <div
                key={key}
                className={`flex flex-col rounded-xl2 border p-6 ${
                  featured
                    ? "border-ember-500 bg-base-900"
                    : "border-base-700 bg-base-900/60"
                }`}
              >
                {featured && (
                  <span className="mb-3 w-fit rounded-full bg-ember-500/15 px-2.5 py-1 text-xs font-medium text-ember-400">
                    Популярный
                  </span>
                )}
                <h2 className="font-display text-xl font-semibold text-white">
                  {plan.label}
                </h2>
                <p className="mt-1 text-sm text-mist-400">{plan.tokens} токенов</p>

                <p className="mt-5 text-3xl font-semibold text-white">
                  {plan.priceRub}
                  <span className="text-base font-normal text-mist-400"> ₽</span>
                </p>

                <ul className="mt-5 flex-1 space-y-2 text-sm text-mist-300">
                  <li>≈ {Math.floor(plan.tokens / TOKEN_COSTS.image)} изображений</li>
                  <li>или ≈ {Math.floor(plan.tokens / TOKEN_COSTS.video)} коротких видео</li>
                  <li>Доступ к фото- и видео-генерации</li>
                </ul>

                <button
                  className={`mt-6 rounded-xl2 px-4 py-2.5 text-sm font-medium transition ${
                    featured
                      ? "bg-ember-500 text-base-950 hover:bg-ember-400"
                      : "border border-base-600 text-mist-300 hover:border-ember-500 hover:text-white"
                  }`}
                >
                  Выбрать план
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
