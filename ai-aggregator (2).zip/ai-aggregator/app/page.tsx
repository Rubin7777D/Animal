import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import ChatClient from "@/components/ChatClient";

export default async function Page() {
  const supabase = createClient();

  // getUser() всегда проверяет токен через Supabase Auth сервер
  // (а не просто читает cookie) — это надёжный способ защитить роут.
  const {
    data: { user },
  } = await supabase.auth.getUser();

  // Доп. страховка на уровне страницы: если вдруг middleware пропустил
  // запрос (например, кэш), всё равно редиректим неавторизованного.
  if (!user) {
    redirect("/auth");
  }

  return (
    <ChatClient
      user={{
        id: user.id,
        email: user.email ?? "",
        username: (user.user_metadata?.username as string | undefined) ?? undefined,
      }}
    />
  );
}
