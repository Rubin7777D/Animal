/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./app/**/*.{js,ts,jsx,tsx}", "./components/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        base: {
          950: "#0D0E12",
          900: "#14151B",
          800: "#1C1E26",
          700: "#272A35",
          600: "#3A3E4C",
        },
        ember: {
          400: "#FFB454",
          500: "#F59E33",
          600: "#D9821F",
        },
        mist: {
          300: "#B7BAC6",
          400: "#8D91A0",
        },
      },
      fontFamily: {
        display: ["var(--font-display)"],
        body: ["var(--font-body)"],
      },
      borderRadius: {
        xl2: "1.1rem",
      },
    },
  },
  plugins: [],
};
