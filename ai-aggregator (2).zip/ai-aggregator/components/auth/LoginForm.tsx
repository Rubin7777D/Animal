"use client";

import { useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

export default function LoginForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const supabase = createClient();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!email || !password) {
      setError("Заполните email и пароль");
      return;
    }

    setLoading(true);
    // Логика "Войти": создаём сессию пользователя по email + паролю.
    const { error: signInError } = await supabase.auth.signInWithPassword({
      email,
      password,
    });
    setLoading(false);

    if (signInError) {
      // Частый случай: email ещё не подтверждён — Supabase вернёт ошибку.
      setError(
        signInError.message === "Email not confirmed"
          ? "Email ещё не подтверждён. Проверьте почту и перейдите по ссылке."
          : "Неверный email или пароль"
      );
      return;
    }

    // Сессия создана (Supabase сам положил cookie) — редирект на сервис генерации.
    const redirectTo = searchParams.get("redirectTo") || "/";
    router.push(redirectTo);
    router.refresh();
  };

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-3">
      <div>
        <label className="mb-1 block text-xs font-medium text-mist-400">
          Email или логин
        </label>
        <input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="you@example.com"
          className="w-full rounded-xl2 border border-base-600 bg-base-800 px-3 py-2.5 text-sm text-white placeholder:text-mist-400 focus:border-ember-500 focus:outline-none"
          autoComplete="email"
        />
      </div>

      <div>
        <label className="mb-1 block text-xs font-medium text-mist-400">Пароль</label>
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="••••••••"
          className="w-full rounded-xl2 border border-base-600 bg-base-800 px-3 py-2.5 text-sm text-white placeholder:text-mist-400 focus:border-ember-500 focus:outline-none"
          autoComplete="current-password"
        />
      </div>

      {error && <p className="text-sm text-red-400">{error}</p>}

      <button
        type="submit"
        disabled={loading}
        className="mt-2 rounded-xl2 bg-ember-500 py-2.5 text-sm font-medium text-base-950 transition hover:bg-ember-400 disabled:opacity-60"
      >
        {loading ? "Входим…" : "Войти"}
      </button>
    </form>
  );
}
