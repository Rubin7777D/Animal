"use client";

import { useState } from "react";
import { createClient } from "@/lib/supabase/client";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export default function RegisterForm() {
  const supabase = createClient();

  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false); // письмо с подтверждением отправлено

  const validate = () => {
    if (!username.trim()) return "Введите имя пользователя";
    if (!EMAIL_RE.test(email)) return "Некорректный формат email";
    if (password.length < 6) return "Пароль должен быть не короче 6 символов";
    if (password !== confirmPassword) return "Пароли не совпадают";
    return null;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const validationError = validate();
    if (validationError) {
      setError(validationError);
      return;
    }
    setError(null);
    setLoading(true);

    // signUp отправляет письмо со ссылкой подтверждения автоматически —
    // это настраивается в Supabase Dashboard → Authentication → Email templates.
    // emailRedirectTo — куда попадёт пользователь после клика по ссылке в письме.
    const { error: signUpError } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: { username }, // сохранится в user_metadata
        emailRedirectTo: `${window.location.origin}/auth/callback`,
      },
    });

    setLoading(false);

    if (signUpError) {
      setError(
        signUpError.message === "User already registered"
          ? "Пользователь с таким email уже зарегистрирован"
          : "Не удалось зарегистрироваться. Попробуйте ещё раз."
      );
      return;
    }

    setSent(true);
  };

  if (sent) {
    return (
      <div className="rounded-xl2 border border-base-600 bg-base-800 p-4 text-sm text-mist-300">
        Мы отправили письмо на <span className="text-white">{email}</span> со
        ссылкой для подтверждения аккаунта. Перейдите по ней — и вы сразу
        окажетесь в сервисе, уже авторизованным.
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-3">
      <div>
        <label className="mb-1 block text-xs font-medium text-mist-400">
          Имя пользователя
        </label>
        <input
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          placeholder="username"
          className="w-full rounded-xl2 border border-base-600 bg-base-800 px-3 py-2.5 text-sm text-white placeholder:text-mist-400 focus:border-ember-500 focus:outline-none"
          autoComplete="username"
        />
      </div>

      <div>
        <label className="mb-1 block text-xs font-medium text-mist-400">Email</label>
        <input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="you@example.com"
          className="w-full rounded-xl2 border border-base-600 bg-base-800 px-3 py-2.5 text-sm text-white placeholder:text-mist-400 focus:border-ember-500 focus:outline-none"
          autoComplete="email"
        />
      </div>

      <div>
        <label className="mb-1 block text-xs font-medium text-mist-400">Пароль</label>
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="Минимум 6 символов"
          className="w-full rounded-xl2 border border-base-600 bg-base-800 px-3 py-2.5 text-sm text-white placeholder:text-mist-400 focus:border-ember-500 focus:outline-none"
          autoComplete="new-password"
        />
      </div>

      <div>
        <label className="mb-1 block text-xs font-medium text-mist-400">
          Подтверждение пароля
        </label>
        <input
          type="password"
          value={confirmPassword}
          onChange={(e) => setConfirmPassword(e.target.value)}
          placeholder="Повторите пароль"
          className="w-full rounded-xl2 border border-base-600 bg-base-800 px-3 py-2.5 text-sm text-white placeholder:text-mist-400 focus:border-ember-500 focus:outline-none"
          autoComplete="new-password"
        />
      </div>

      {error && <p className="text-sm text-red-400">{error}</p>}

      <button
        type="submit"
        disabled={loading}
        className="mt-2 rounded-xl2 bg-ember-500 py-2.5 text-sm font-medium text-base-950 transition hover:bg-ember-400 disabled:opacity-60"
      >
        {loading ? "Отправляем…" : "Зарегистрироваться"}
      </button>
    </form>
  );
}
