"use client";

import { useState } from "react";
import LoginForm from "@/components/auth/LoginForm";
import RegisterForm from "@/components/auth/RegisterForm";
import GoogleButton from "@/components/auth/GoogleButton";

export default function AuthTabs() {
  const [tab, setTab] = useState<"login" | "register">("login");

  return (
    <div className="w-full max-w-sm rounded-xl2 border border-base-700 bg-base-900 p-6">
      <h1 className="text-center font-display text-2xl font-semibold text-white">
        Aria
      </h1>

      {/* Переключатель вкладок */}
      <div className="mt-6 flex rounded-xl2 border border-base-700 bg-base-800 p-1">
        <button
          onClick={() => setTab("login")}
          className={`flex-1 rounded-lg py-2 text-sm font-medium transition ${
            tab === "login" ? "bg-base-700 text-white" : "text-mist-400"
          }`}
        >
          Войти
        </button>
        <button
          onClick={() => setTab("register")}
          className={`flex-1 rounded-lg py-2 text-sm font-medium transition ${
            tab === "register" ? "bg-base-700 text-white" : "text-mist-400"
          }`}
        >
          Зарегистрироваться
        </button>
      </div>

      <div className="mt-5">
        {tab === "login" ? <LoginForm /> : <RegisterForm />}
      </div>

      <div className="my-5 flex items-center gap-3">
        <div className="h-px flex-1 bg-base-700" />
        <span className="text-xs text-mist-400">или</span>
        <div className="h-px flex-1 bg-base-700" />
      </div>

      {/* Кнопка Google — доступна и на "Войти", и на "Зарегистрироваться" */}
      <GoogleButton />
    </div>
  );
}
