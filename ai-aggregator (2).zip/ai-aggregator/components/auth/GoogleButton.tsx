"use client";

import { createClient } from "@/lib/supabase/client";

export default function GoogleButton() {
  const supabase = createClient();

  const handleGoogleLogin = async () => {
    // Redirect-флоу OAuth: пользователя уводит на Google, а после
    // согласия Google возвращает его на /auth/callback с кодом сессии.
    await supabase.auth.signInWithOAuth({
      provider: "google",
      options: {
        redirectTo: `${window.location.origin}/auth/callback`,
      },
    });
  };

  return (
    <button
      type="button"
      onClick={handleGoogleLogin}
      className="flex w-full items-center justify-center gap-2 rounded-xl2 border border-base-600 bg-base-800 py-2.5 text-sm font-medium text-mist-300 transition hover:border-mist-400 hover:text-white"
    >
      <svg width="16" height="16" viewBox="0 0 18 18">
        <path fill="#4285F4" d="M17.6 9.2c0-.6-.05-1.2-.15-1.75H9v3.3h4.8c-.2 1.1-.85 2.05-1.8 2.65v2.2h2.9c1.7-1.55 2.7-3.85 2.7-6.4z"/>
        <path fill="#34A853" d="M9 18c2.4 0 4.45-.8 5.9-2.15l-2.9-2.2c-.8.55-1.85.85-3 .85-2.3 0-4.25-1.55-4.95-3.65H1.05v2.3C2.5 15.95 5.5 18 9 18z"/>
        <path fill="#FBBC05" d="M4.05 10.85c-.2-.55-.3-1.15-.3-1.85s.1-1.3.3-1.85v-2.3H1.05C.4 6.15 0 7.55 0 9s.4 2.85 1.05 4.15z"/>
        <path fill="#EA4335" d="M9 3.6c1.3 0 2.5.45 3.4 1.35l2.55-2.55C13.45.9 11.4 0 9 0 5.5 0 2.5 2.05 1.05 4.85l3 2.3C4.75 5.05 6.7 3.6 9 3.6z"/>
      </svg>
      Войти через Google
    </button>
  );
}
