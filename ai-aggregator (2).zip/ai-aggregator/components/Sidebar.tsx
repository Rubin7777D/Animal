"use client";

import Link from "next/link";

export type ChatItem = {
  id: string;
  title: string;
};

export default function Sidebar({
  chats,
  activeId,
  onSelect,
  onNewChat,
  open,
  onClose,
}: {
  chats: ChatItem[];
  activeId: string | null;
  onSelect: (id: string) => void;
  onNewChat: () => void;
  open: boolean;
  onClose: () => void;
}) {
  return (
    <>
      {open && (
        <div
          className="fixed inset-0 z-20 bg-black/50 md:hidden"
          onClick={onClose}
        />
      )}
      <aside
        className={`fixed z-30 md:static md:z-auto h-full w-72 shrink-0 border-r border-base-700 bg-base-900 px-3 py-4 transition-transform md:translate-x-0 ${
          open ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <button
          onClick={onNewChat}
          className="flex w-full items-center gap-2 rounded-xl2 border border-base-600 bg-base-800 px-3 py-2.5 text-sm font-medium text-mist-300 transition hover:border-ember-500 hover:text-white"
        >
          <PlusIcon />
          Новый чат
        </button>

        <div className="mt-6 flex items-center justify-between px-1">
          <span className="text-xs font-medium uppercase tracking-wide text-mist-400">
            История
          </span>
        </div>

        <nav className="mt-2 flex flex-col gap-0.5 overflow-y-auto" style={{ maxHeight: "calc(100% - 160px)" }}>
          {chats.length === 0 && (
            <p className="px-2 py-3 text-sm text-mist-400">
              Здесь появятся твои чаты
            </p>
          )}
          {chats.map((chat) => (
            <button
              key={chat.id}
              onClick={() => onSelect(chat.id)}
              className={`truncate rounded-lg px-3 py-2 text-left text-sm transition ${
                chat.id === activeId
                  ? "bg-base-800 text-white"
                  : "text-mist-300 hover:bg-base-800/60"
              }`}
            >
              {chat.title}
            </button>
          ))}
        </nav>

        <div className="absolute bottom-4 left-3 right-3 flex items-center justify-between rounded-xl2 border border-base-700 bg-base-800 px-3 py-2.5">
          <Link href="/pricing" className="text-sm font-medium text-ember-400 hover:text-ember-300">
            Тарифы
          </Link>
          <span className="text-xs text-mist-400">300 токенов</span>
        </div>
      </aside>
    </>
  );
}

function PlusIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
      <path d="M8 2.5V13.5M2.5 8H13.5" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
    </svg>
  );
}
