"use client";

import { useState } from "react";
import Sidebar, { ChatItem } from "@/components/Sidebar";
import GenerationBar, { GenMode } from "@/components/GenerationBar";
import UserMenu from "@/components/UserMenu";

type Message = {
  id: string;
  role: "user" | "assistant";
  mode: GenMode;
  content: string;
  imageUrl?: string;
};

type Chat = {
  id: string;
  title: string;
  messages: Message[];
};

// Принимает данные уже авторизованного пользователя — их достаёт
// серверный app/page.tsx и передаёт сюда пропом.
export default function ChatClient({
  user,
}: {
  user: { id: string; email: string; username?: string };
}) {
  const [chats, setChats] = useState<Chat[]>([]);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [loading, setLoading] = useState(false);

  const activeChat = chats.find((c) => c.id === activeId) ?? null;

  const newChat = () => {
    setActiveId(null);
    setSidebarOpen(false);
  };

  const handleSubmit = async (prompt: string, mode: GenMode) => {
    let chatId = activeId;
    const userMsg: Message = { id: crypto.randomUUID(), role: "user", mode, content: prompt };

    if (!chatId) {
      chatId = crypto.randomUUID();
      const title = prompt.length > 40 ? prompt.slice(0, 40) + "…" : prompt;
      setChats((prev) => [{ id: chatId!, title, messages: [userMsg] }, ...prev]);
      setActiveId(chatId);
    } else {
      setChats((prev) =>
        prev.map((c) => (c.id === chatId ? { ...c, messages: [...c.messages, userMsg] } : c))
      );
    }

    setLoading(true);
    try {
      const endpoint = mode === "photo" ? "/api/generate/image" : "/api/generate/video";
      const res = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt, userId: user.id }),
      });
      const data = await res.json();

      const assistantMsg: Message = {
        id: crypto.randomUUID(),
        role: "assistant",
        mode,
        content: res.ok
          ? mode === "photo"
            ? "Готово (демо-ответ)."
            : `Задача поставлена в очередь: ${data.taskId ?? "—"}`
          : `Ошибка: ${data.error ?? "не удалось выполнить запрос"}`,
        imageUrl: data.imageUrl,
      };

      setChats((prev) =>
        prev.map((c) =>
          c.id === chatId ? { ...c, messages: [...c.messages, assistantMsg] } : c
        )
      );
    } finally {
      setLoading(false);
    }
  };

  const sidebarChats: ChatItem[] = chats.map((c) => ({ id: c.id, title: c.title }));

  return (
    <div className="flex h-dvh overflow-hidden">
      <Sidebar
        chats={sidebarChats}
        activeId={activeId}
        onSelect={(id) => {
          setActiveId(id);
          setSidebarOpen(false);
        }}
        onNewChat={newChat}
        open={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
      />

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="flex items-center justify-between gap-3 border-b border-base-800 px-4 py-3">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setSidebarOpen(true)}
              aria-label="Меню"
              className="text-mist-300 md:hidden"
            >
              <MenuIcon />
            </button>
            <span className="font-display text-sm font-semibold text-white">Aria</span>
          </div>
          <UserMenu email={user.email} username={user.username} />
        </header>

        <main className="flex flex-1 flex-col overflow-y-auto">
          {!activeChat || activeChat.messages.length === 0 ? (
            <div className="flex flex-1 flex-col items-center justify-center px-6 text-center">
              <h1 className="font-display text-3xl font-semibold text-white md:text-4xl">
                Что создадим сегодня?
              </h1>
              <p className="mt-3 max-w-md text-sm text-mist-400">
                Опиши фото или видео словами — остальное сделают модели снизу.
              </p>
            </div>
          ) : (
            <div className="mx-auto w-full max-w-2xl flex-1 space-y-4 px-4 py-6">
              {activeChat.messages.map((m) => (
                <div
                  key={m.id}
                  className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className={`max-w-[85%] rounded-xl2 px-4 py-2.5 text-sm ${
                      m.role === "user"
                        ? "bg-ember-500 text-base-950"
                        : "bg-base-800 text-mist-300"
                    }`}
                  >
                    {m.content}
                    {m.imageUrl && (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img
                        src={m.imageUrl}
                        alt="Результат генерации"
                        className="mt-2 rounded-lg"
                      />
                    )}
                  </div>
                </div>
              ))}
              {loading && (
                <div className="flex justify-start">
                  <div className="rounded-xl2 bg-base-800 px-4 py-2.5 text-sm text-mist-400">
                    Генерирую…
                  </div>
                </div>
              )}
            </div>
          )}

          <GenerationBar onSubmit={handleSubmit} disabled={loading} />
        </main>
      </div>
    </div>
  );
}

function MenuIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
      <path d="M3 6h14M3 10h14M3 14h14" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
    </svg>
  );
}
