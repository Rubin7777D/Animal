"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

export default function UserMenu({
  email,
  username,
}: {
  email: string;
  username?: string;
}) {
  const router = useRouter();
  const supabase = createClient();
  const [open, setOpen] = useState(false);

  const displayName = username || email.split("@")[0];
  const initial = displayName.charAt(0).toUpperCase();

  const handleLogout = async () => {
    await supabase.auth.signOut();
    router.push("/auth");
    router.refresh();
  };

  return (
    <div className="relative">
      <button
        onClick={() => setOpen((v) => !v)}
        className="flex items-center gap-2 rounded-xl2 border border-base-700 bg-base-800 px-2.5 py-1.5 text-sm text-mist-300 hover:border-base-600"
      >
        <span className="flex h-6 w-6 items-center justify-center rounded-full bg-ember-500 text-xs font-semibold text-base-950">
          {initial}
        </span>
        <span className="hidden max-w-[120px] truncate sm:inline">{displayName}</span>
      </button>

      {open && (
        <>
          {/* Клик вне меню закрывает его */}
          <div className="fixed inset-0 z-10" onClick={() => setOpen(false)} />
          <div className="absolute right-0 z-20 mt-2 w-56 rounded-xl2 border border-base-700 bg-base-900 p-3 shadow-xl">
            <p className="truncate text-sm font-medium text-white">{displayName}</p>
            <p className="truncate text-xs text-mist-400">{email}</p>
            <button
              onClick={handleLogout}
              className="mt-3 w-full rounded-lg border border-base-600 py-2 text-sm text-red-400 hover:border-red-400 hover:bg-red-400/10"
            >
              Выйти с аккаунта
            </button>
          </div>
        </>
      )}
    </div>
  );
}
