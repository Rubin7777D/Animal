"use client";

import { useState } from "react";

export type GenMode = "photo" | "video";

export default function GenerationBar({
  onSubmit,
  disabled,
}: {
  onSubmit: (prompt: string, mode: GenMode) => void;
  disabled?: boolean;
}) {
  const [mode, setMode] = useState<GenMode>("photo");
  const [value, setValue] = useState("");

  const submit = () => {
    if (!value.trim() || disabled) return;
    onSubmit(value.trim(), mode);
    setValue("");
  };

  return (
    <div className="mx-auto w-full max-w-2xl px-4 pb-6">
      <div className="rounded-xl2 border border-base-700 bg-base-900 p-2 shadow-lg shadow-black/20">
        <div className="flex gap-1 px-1 pb-2 pt-1">
          <ModeButton active={mode === "photo"} onClick={() => setMode("photo")} label="Фото" />
          <ModeButton active={mode === "video"} onClick={() => setMode("video")} label="Видео" />
        </div>
        <div className="flex items-end gap-2">
          <textarea
            value={value}
            onChange={(e) => setValue(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                submit();
              }
            }}
            placeholder={mode === "photo" ? "Опиши изображение…" : "Опиши сцену для видео…"}
            rows={1}
            className="max-h-40 flex-1 resize-none bg-transparent px-2 py-2 text-sm text-white placeholder:text-mist-400 focus:outline-none"
          />
          <button
            onClick={submit}
            disabled={disabled || !value.trim()}
            className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-ember-500 text-base-950 transition hover:bg-ember-400 disabled:cursor-not-allowed disabled:bg-base-700 disabled:text-mist-400"
            aria-label="Отправить"
          >
            <ArrowUp />
          </button>
        </div>
      </div>
    </div>
  );
}

function ModeButton({
  active,
  onClick,
  label,
}: {
  active: boolean;
  onClick: () => void;
  label: string;
}) {
  return (
    <button
      onClick={onClick}
      className={`rounded-md px-3 py-1 text-xs font-medium transition ${
        active
          ? "bg-ember-500/15 text-ember-400"
          : "text-mist-400 hover:text-mist-300"
      }`}
    >
      {label}
    </button>
  );
}

function ArrowUp() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
      <path d="M8 13V3M8 3L3.5 7.5M8 3L12.5 7.5" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
