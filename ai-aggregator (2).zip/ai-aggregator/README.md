# Forge — каркас агрегатора AI-генерации

Next.js (App Router, TypeScript, Tailwind) со встроенным бэкендом (API routes),
чат-интерфейс + страница тарифов. Без реальных ключей API-роуты отдают мок-ответы,
так что фронтенд можно тестировать сразу.

## Запуск

```bash
npm install
cp .env.example .env.local   # вставь свои ключи
npm run dev
```

## Что уже есть

- `app/page.tsx` — чат: сайдбар с историей, кнопка «Новый чат», приветствие по центру,
  нижняя панель с переключателем Фото/Видео. Теперь **защищённый маршрут** —
  серверный компонент, проверяет сессию Supabase и редиректит на `/auth`,
  если пользователь не вошёл.
- `app/auth/page.tsx` — страница входа/регистрации с вкладками (`AuthTabs`),
  формами (`LoginForm`, `RegisterForm`) и кнопкой `GoogleButton`.
- `app/auth/callback/route.ts` — сюда попадает пользователь и из письма
  подтверждения email, и после Google OAuth; обменивает `code` на сессию.
- `middleware.ts` — на каждый запрос обновляет токен сессии и редиректит
  неавторизованных на `/auth` (Protected Route на уровне всего приложения).
- `components/UserMenu.tsx` — аватар/имя в шапке + кнопка «Выйти с аккаунта».
- `supabase/schema.sql` — таблица `profiles` с балансом токенов,
  автосоздание профиля при регистрации, функция атомарного списания токенов.
- `app/pricing/page.tsx` — 3 тарифа (300 / 600 / 1200 токенов), логика берётся из `lib/tokens.ts`.
- `app/api/generate/image/route.ts` — вызов Nano Banana (Gemini `gemini-2.5-flash-image`).
- `app/api/generate/video/route.ts` — вызов Volcengine Ark (Seedance).
- `app/api/tokens/route.ts` — баланс токенов.
- `lib/tokens.ts` — стоимость генераций и баланс (сейчас в памяти процесса — демо,
  см. `supabase/schema.sql` для переноса в реальную БД).

## Настройка авторизации (Supabase)

1. Создай проект на [supabase.com](https://supabase.com) (бесплатный тариф подходит для старта).
2. Скопируй `Project URL` и `anon public key` из **Project Settings → API**
   в `.env.local` (`NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`).
3. **Authentication → URL Configuration**: укажи
   `Site URL = http://localhost:3000` (потом смени на боевой домен),
   и добавь в `Redirect URLs`: `http://localhost:3000/auth/callback`.
4. **Authentication → Providers → Email**: включено по умолчанию,
   подтверждение email тоже включено по умолчанию ("Confirm email").
   При желании отредактируй шаблон письма в **Authentication → Email Templates**.
5. **Authentication → Providers → Google**: включи, вставь `Client ID` и
   `Client Secret` из Google Cloud Console (OAuth consent screen +
   OAuth 2.0 Client ID, тип "Web application", Authorized redirect URI —
   тот, что покажет сама форма Supabase на этой странице).
6. Открой **SQL Editor** и выполни `supabase/schema.sql` — создаст таблицу
   профилей с токенами и триггер, который заводит профиль каждому новому
   пользователю (и через email/пароль, и через Google).

## Как это работает

- **Регистрация**: `RegisterForm` вызывает `supabase.auth.signUp()`.
  Supabase сам отправляет письмо со ссылкой подтверждения. Ссылка ведёт
  на `/auth/callback?code=...` → сессия создаётся → редирект на `/` (уже
  авторизован).
- **Вход**: `LoginForm` вызывает `supabase.auth.signInWithPassword()` —
  сессия создаётся сразу, редирект на `/`.
- **Google**: `GoogleButton` вызывает `supabase.auth.signInWithOAuth()`,
  Google возвращает пользователя на тот же `/auth/callback`.
- **Защита роутов**: `middleware.ts` проверяет сессию на каждый запрос;
  плюс `app/page.tsx` (серверный компонент) дополнительно проверяет
  `supabase.auth.getUser()` перед рендером.

## Что нужно доделать перед продакшеном

1. **API-роуты генерации на реальную БД** — `app/api/generate/*` пока читают/пишут
   баланс через `lib/tokens.ts` (в памяти процесса). Перепиши их на вызов
   `deduct_tokens()` из `supabase/schema.sql` через серверный Supabase-клиент —
   так списание токенов станет атомарным и переживёт перезапуск сервера.
2. **Оплата тарифов** — кнопка «Выбрать план» на `/pricing` сейчас ничего не делает.
   Подключи платёжный шлюз (ЮKassa/CloudPayments/Stripe) и обработчик webhook,
   который зачисляет токены через `update profiles set token_balance = ...`.
3. **Видео — опрос статуса задачи** — Volcengine Seedance асинхронный: после
   создания задачи нужен поллинг `GET .../tasks/{task_id}` до готовности видео,
   плюс отдача ссылки на результат в чат.
4. **Хранение результатов** — сохраняй сгенерированные фото/видео в S3-совместимое
   хранилище (важно: не хранить их только в ответе API — ссылки от провайдеров
   часто временные).
5. **Рейт-лимиты и логи ошибок провайдеров** — оба API могут отдавать 429/5xx,
   нужна очередь повторов.
6. **Смена пароля / забыли пароль** — Supabase поддерживает `resetPasswordForEmail()`,
   но экрана для этого в проекте пока нет — добавь по аналогии с `LoginForm`.

## Структура

```
app/
  page.tsx                  — главный чат (Protected Route, серверный)
  auth/page.tsx              — вход / регистрация
  auth/callback/route.ts     — обмен code → сессия (email confirm + Google)
  auth/auth-code-error/      — просроченная/невалидная ссылка
  pricing/page.tsx           — тарифы
  api/generate/image/        — Nano Banana proxy
  api/generate/video/        — Volcengine Seedance proxy
  api/tokens/                — баланс
components/
  ChatClient.tsx
  Sidebar.tsx
  GenerationBar.tsx
  UserMenu.tsx
  auth/
    AuthTabs.tsx
    LoginForm.tsx
    RegisterForm.tsx
    GoogleButton.tsx
lib/
  tokens.ts
  supabase/
    client.ts               — Supabase-клиент для браузера
    server.ts                — Supabase-клиент для сервера
middleware.ts                — защита роутов + обновление сессии
supabase/
  schema.sql                 — таблица profiles, триггер, deduct_tokens()
```
